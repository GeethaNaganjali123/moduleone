package MobileBeans;

public class MobileBean extends CustomerBeans {

	 int mobileModel;
	String mobileName;
	double mobileprice;
	
	public String getMobileName() {
		return mobileName;
	}
	public void setMobileName(String mobileName) {
		this.mobileName = mobileName;
	}
	public double getMobileprice() {
		return mobileprice;
	}
	public void setMobileprice(double mobileprice) {
		this.mobileprice = mobileprice;
	}
	public int getMobileModel() {
		return mobileModel;
	}
	public void setMobileModel(int string) {
		this.mobileModel = string;
	}
	
	
	
	
		
	

	public MobileBean( int mobileModel,String mobileName, double mobileprice) {
	
		this.mobileName = mobileName;
		this.mobileprice = mobileprice;
		this.mobileModel = mobileModel;
	}
	public MobileBean() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return ""
	
				
				+"mobileName=" + mobileName
				+ "\n mobileprice=" + mobileprice
				+ "\n mobileModel=" + mobileModel+"\n";
				
	}
	
	
	
	
}
