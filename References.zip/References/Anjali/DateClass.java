package demo;
import java.util.*;
public class DateClass {
	public static void main(String args[]) {
		Date d1=new Date();
		Date d2=new Date(9779999999999L);
		Date d3=new Date(9999999999967L);
		System.out.println(d1);
		System.out.println(d2);
		System.out.println(d3);
		if(d3.before(d1))
			System.out.println("true");
		else
			System.out.println("false");
		if(d3.after(d1))
			System.out.println("true");
		else
			System.out.println("false");
	}

}
