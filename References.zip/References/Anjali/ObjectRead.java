package demo;

import java.io.*;

public class ObjectRead {
	public static void main(String args[])throws Exception{
		ObjectInputStream obj=null;
		int objCount=0;
		ObjectReaderWrite object=null;
		obj=new ObjectInputStream(new BufferedInputStream(new FileInputStream("C:\\Users\\rosbalaj\\Desktop\\roshni\\read.txt")));
		while(objCount<3) {
			object=(ObjectReaderWrite)obj.readObject();
			objCount++;
			System.out.println(object);
		}
		obj.close();
	}

	
}
