package demo;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class ObjectWrite {
	public static void main(String args[])throws Exception{
		ObjectReaderWrite obj1=new ObjectReaderWrite("A","h");
		ObjectReaderWrite obj2=new ObjectReaderWrite("B","he");
		ObjectReaderWrite obj3=new ObjectReaderWrite("C","hey");
	ObjectOutputStream objout=new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream("C:\\Users\\rosbalaj\\Desktop\\roshni\\read.bin")));
	objout.writeObject(obj1);
	objout.writeObject(obj2);
	objout.writeObject(obj3);
	objout.close();
	
	}
	
	

}
