package demo;

import java.util.*;
import java.util.stream.IntStream;

public class ReduceCollectionDemo {
	public static void main(String args[]) {
		OptionalInt reducedInt=IntStream.range(1,5).reduce((a,b)->a+b);//1st inc and las exc
		System.out.println(reducedInt.getAsInt());
	}

}
