package com.service;
import com.bean.*;
import com.dao.*;
import com.ui.EmployeeDetailsInput;

public class Service{
	EmployeeDAO daoObj=new EmployeeDAO();
public void storeInService(Employee obj) {
	
	int sal=obj.getSalary();
	String name=obj.getName();
	
	if(sal>5000 && sal<20000 && name.equals("System Associate") || name.equals("system associate") ) {
		
		obj.setScheme("Scheme C");
	}
	else if(sal>=20000 && sal<40000 && name.equals("Programmer") || name.equals("programmer")) {
		obj.setScheme("Scheme B");
	}
	else if(sal>=40000 && name.equals("Manager")|| name.equals("manager")) {
		obj.setScheme("Scheme A");
		
	}
	else if(sal<5000 && name.equals("Clerk") || name.equals("clerk")) {
		obj.setScheme("NoScheme");
	}
	
	
		daoObj.storeInDAO(obj);

		
	}
public void Validate(Employee obj2) {
	Service empsrObj=new Service();
	int sal=obj2.getSalary();
	String name=obj2.getName();
	if(name.matches("[A-Z]+([A-Z])*")){
		System.out.println("Data is Valid");
		empsrObj.storeInService(obj2);
	}
	else {
		System.out.println("Data is Invalid Enter Again:");
		EmployeeDetailsInput inpObj= new EmployeeDetailsInput();
		inpObj.takeDetails();
	}
}

}
