package demo;
import java.text.*;
import java.util.Date;

public class SimpleDateFormatDemo {
	public static void mian(String args[]) {
		Date d=new Date();
		System.out.println(d);
		DateFormat dobj=new SimpleDateFormat("dd.mm.yyyy");
		System.out.println(dobj.format(d));
		DateFormat dobj1=new SimpleDateFormat("HH:MM:SS");
		System.out.println(dobj1.format(d));
		
	}

}
