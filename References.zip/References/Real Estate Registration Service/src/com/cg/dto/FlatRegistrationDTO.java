package com.cg.dto;

public class FlatRegistrationDTO {
	private int id;
	private String FT;
	private double FA;
	private double RA;
	private double DA;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFT() {
		return FT;
	}
	public void setFT(String fT) {
		FT = fT;
	}
	public double getFA() {
		return FA;
	}
	public void setFA(double fA) {
		FA = fA;
	}
	public double getRA() {
		return RA;
	}
	public void setRA(double rA) {
		RA = rA;
	}
	public double getDA() {
		return DA;
	}
	public void setDA(double dA) {
		DA = dA;
	}
	

}
